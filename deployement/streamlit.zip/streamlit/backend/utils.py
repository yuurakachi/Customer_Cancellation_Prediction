import json
import os   
import pandas as pd

# Rutas fijas para los archivos
USER_FILE = "usuarios.json"
PROFILE_FILE = "perfiles.json"
ACCIONES_FILE = "acciones_guardadas.csv"  

def cargar_usuarios():
    if os.path.exists(USER_FILE):
        with open(USER_FILE, "r") as f:
            return json.load(f)
    return {}

def guardar_usuarios(usuarios):
    with open(USER_FILE, "w") as f:
        json.dump(usuarios, f)

def cargar_perfiles():
    if os.path.exists(PROFILE_FILE):
        with open(PROFILE_FILE, "r") as f:
            return json.load(f)
    return {}

def guardar_perfiles(perfiles):
    with open(PROFILE_FILE, "w") as f:
        json.dump(perfiles, f)


def guardar_acciones(nueva_fila):
    if isinstance(nueva_fila, pd.Series):
        nueva_fila = nueva_fila.to_frame().T

    columnas_deseadas = [
        "ID_Reserva", 
        "Usuario", 
        "Promoción Ofrecida", 
        "Contacto",
        "Probabilidad de cancelación",
        "Comentario"]

    if not os.path.exists(ACCIONES_FILE):
        nueva_fila[columnas_deseadas].to_csv(ACCIONES_FILE, index=False)
    else:
        nueva_fila[columnas_deseadas].to_csv(ACCIONES_FILE, mode="a", header=False, index=False)

def cargar_acciones():
    if os.path.exists(ACCIONES_FILE):
        return pd.read_csv(ACCIONES_FILE)
    else:
        return pd.DataFrame(columns=["ID_Reserva", "Usuario", "Promoción Ofrecida", "Contacto", "Probabilidad de cancelación","Comentario"])
