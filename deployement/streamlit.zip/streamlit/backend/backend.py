### PAQUETES ###
import pandas as pd
import pyodbc # type: ignore
import numpy as np
import json
import joblib
from datetime import datetime
from sklearn.preprocessing import OneHotEncoder
from category_encoders import TargetEncoder
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings("ignore")


### CARGAR SETS DE DATOS ### 
def load_datasets(reservation_data, agency_data):
    # reservation_data = pd.read_csv(path_reservations)
    # agency_data = pd.read_csv(path_agencies)

    # Extraer la informaicón de las agencias relevantes
    relevant_agencies = reservation_data['ID_Agencia'].unique()
    agency_data = agency_data[agency_data['ID_Agencia'].isin(relevant_agencies)]

    # Juntar las tablas de reservaciones y agencias
    data = reservation_data.merge(agency_data[['ID_Agencia', 'Estado_cve', 'Pais_cod']], on="ID_Agencia", how="left")
    data.rename(columns={"Estado_cve": "Estado_cve_agencia", "Pais_cod": "Pais_cod_agencia"}, inplace=True)
    
    # Mantener solo las colummnas relevantes en primera instancia
    data = data[['ID_Reserva', 'h_res_fec', 'h_tot_hab', 'ID_Paquete', 'ID_Segmento_Comp', 'ID_Agencia', 'ID_Tipo_Habitacion', 
            'ID_canal', 'ID_Pais_Origen', 'h_can_res', 'h_edo', 'Estado_cve_agencia', 'Pais_cod_agencia',
            'h_fec_lld', 'h_num_adu', 'h_num_men']]
    
    return data

### CORRECCIÓN DE TIPO DE DATOS ###
def correct_data_types(data):
    int_cols = ['h_tot_hab', 'h_num_adu', 'h_num_men']
    data[int_cols] = data[int_cols].astype('Int64')

    # Convertir las variables categoricas a tipo 'category'
    category_cols = ['ID_Reserva', 'ID_Paquete', 'ID_Segmento_Comp', 'ID_Agencia', 'ID_Tipo_Habitacion', 'ID_canal', 
                    'ID_Pais_Origen', 'h_can_res', 'h_edo', 'Estado_cve_agencia', 'Pais_cod_agencia']
    data[category_cols] = data[category_cols].astype('category')

    # Convertir las variables de fecha a tipo 'datetime'
    data = data.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    data['h_res_fec'] = data['h_res_fec'].apply(lambda x: pd.to_datetime(x, format='%Y-%m-%d %H:%M:%S.%f', errors='ignore'))
    data['h_res_fec'] = data['h_res_fec'].apply(lambda x: pd.to_datetime(x, format='%Y%m%d', errors='ignore'))
    data['h_res_fec'] = data['h_res_fec'].apply(lambda x: pd.to_datetime(x, format='%Y-%m-%d', errors='ignore'))

    data['h_fec_lld'] = data['h_fec_lld'].apply(lambda x: pd.to_datetime(x, format='%Y-%m-%d %H:%M:%S.%f', errors='ignore'))
    data['h_fec_lld'] = data['h_fec_lld'].apply(lambda x: pd.to_datetime(x, format='%Y%m%d', errors='ignore'))
    data['h_fec_lld'] = data['h_fec_lld'].apply(lambda x: pd.to_datetime(x, format='%Y-%m-%d', errors='ignore'))

    return data

### GENERAR VARIABLES DERIVDADS ###
def generate_derived_variables(data):
    # Crear nuevas variable: Antelación con la cual se hizo la reserva
    data['days_diff_res_lld'] = (data['h_fec_lld'] - data['h_res_fec']).dt.days
    data.drop(['h_res_fec'], axis=1, inplace=True)

    # Rescribir ID_Pais_Origen como nacional(1) o extranjero(0)
    data['Pais_Origen'] = data['ID_Pais_Origen'].apply(lambda x: 1 if x == 157 else 0)
    data.drop(['ID_Pais_Origen'], axis=1, inplace=True)

    # Generar la variable de tarifa por noche por habitacion.
    ## Se usa un meapeo generado previamente, valores ausentes se llenan con la media.
    with open(r"transformations\avg_noc_dict.json", "r") as f:
        loaded_dict = json.load(f)

    mean_avg_noc = sum(loaded_dict.values()) / len(loaded_dict)
    data['tarif'] = data['ID_Tipo_Habitacion'].map(loaded_dict).fillna(mean_avg_noc)

    return data

### GENERAR DATOS PARA VISUALIZACIÓN ###
def generate_visualization_data(data):
    # Corrgeir tipo de datos
    vis_data = correct_data_types(data)

    # Generar variables derivadas
    vis_data = generate_derived_variables(vis_data)

    # Exportar los datos a un archivo parquet
    vis_data.to_parquet("vis_data.parquet", index=False)

    return vis_data

### PREPARAR DATOS PARA MODELOS ###
def prepare_data_for_models(data):
    data_model = data.copy()

    data_model = correct_data_types(data_model)

    # Generar variables derivadas
    data_model = generate_derived_variables(data_model)
    print(data_model.info())

    # Segmentar la fecha de llegada en día, mes y año
    data_model['mes_llegada'] = data_model['h_fec_lld'].dt.month
    data_model['year_llegada'] = data_model['h_fec_lld'].dt.year
    data_model['dia_llegada'] = data_model['h_fec_lld'].dt.day
    data_model.drop(columns=['h_fec_lld'],inplace=True)

    # Transformar las variables categóricas nominales de cardinalidad moderada o baja utilizando OneHotEncoder
    ONE_vars = ['ID_Paquete', 'ID_Segmento_Comp', 'ID_Agencia', 'ID_Tipo_Habitacion', 'ID_canal', 'h_can_res', 
                'Estado_cve_agencia', 'Pais_cod_agencia', 'Pais_Origen']

    # data_model[ONE_vars] = data_model[ONE_vars].fillna("Missing")
    # data_model = data_model[data_model.ne("Missing").all(axis=1)]
    # data_model = data_model.dropna(subset=ONE_vars)

    encoder_ONE_loaded = joblib.load(r'transformations\encoder_ONE.pkl')

    # ONE_feature_names = encoder_ONE_loaded.get_feature_names_out(ONE_vars)  # Get the feature names

    # encoded_ONE_data = encoder_ONE_loaded.transform(data_model[ONE_vars])
    # encoded_ONE_df = pd.DataFrame(encoded_ONE_data, columns=ONE_feature_names)

    # Ensure all data is string type (if categorical text)
    data_model[ONE_vars] = data_model[ONE_vars].astype(str)

    # Transform using the trained encoder
    encoded_ONE_data = encoder_ONE_loaded.transform(data_model[ONE_vars])

    # Get matching feature names
    ONE_feature_names = encoder_ONE_loaded.get_feature_names_out(ONE_vars)

    # Wrap in DataFrame
    encoded_ONE_df = pd.DataFrame(encoded_ONE_data, columns=ONE_feature_names)

    data_model = pd.concat([data_model.drop(columns=ONE_vars).reset_index(drop=True), encoded_ONE_df.reset_index(drop=True)], axis=1)

    # Transformar las variables categóricas de alta cardinalidad utilizando TaregetEncoder
    try: 
        encoder_target_loaded = joblib.load('target_encoder.pkl')
    except FileNotFoundError: 
        encoder_target_loaded = joblib.load(r'transformations\target_encoder.pkl')

    data_model['h_edo_target_enc'] = encoder_target_loaded.transform(data_model['h_edo'])
    data_model['h_edo_target_enc'] = data_model['h_edo_target_enc'].fillna(0)
    data_model = data_model.drop('h_edo', axis=1)

    # Estandarizar las variables numéricas
    try: 
        encoder_standard_loaded = joblib.load('standard_scaler.pkl')
    except FileNotFoundError: 
        encoder_standard_loaded = joblib.load(r'transformations\standard_scaler.pkl')

    cols_to_standardize = ['tarif', 'days_diff_res_lld', 'h_tot_hab', 'mes_llegada', 'year_llegada', 'dia_llegada',
                        'h_num_adu', 'h_num_men']
    data_model[cols_to_standardize] = encoder_standard_loaded.transform(data_model[cols_to_standardize])

    data_model.to_parquet("data_model.parquet", index=False)

    return data_model