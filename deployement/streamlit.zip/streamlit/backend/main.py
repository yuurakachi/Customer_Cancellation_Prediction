import streamlit as st
import pandas as pd
import os
import joblib
import json
from utils import cargar_usuarios, guardar_usuarios, cargar_perfiles, guardar_perfiles, cargar_acciones, guardar_acciones
from prediccion import run_prediccion
from consulta import run_consulta
from reportes import run_reportes
from configuracion import run_configuracion
   
# Configuración de la página
st.set_page_config(page_title="Gestión de Cancelaciones", layout="centered")

# Cargar modelo Random Forest
file_path = "randomforest_model.pkl"
if os.path.exists(file_path):
    modelo_rf = joblib.load("randomforest_model.pkl")
else:
    modelo_rf = None

# Inicializar usuarios simulados y estados
if "users" not in st.session_state:
    st.session_state.users = cargar_usuarios()

if "user_profiles" not in st.session_state:
    st.session_state.user_profiles = cargar_perfiles()

if "user_data_records" not in st.session_state:
    st.session_state.user_data_records = {}

if "authenticated" not in st.session_state:
    st.session_state.authenticated = False

if "username" not in st.session_state:
    st.session_state.username = ""

# Estado para manejo de vista
if "login_mode" not in st.session_state:
    st.session_state.login_mode = "login"

if "acciones_guardadas" not in st.session_state:
    st.session_state.acciones_guardadas = cargar_acciones()

# Verifica credenciales
def check_credentials(username, password):
    return st.session_state.users.get(username) == password

def main():
    if not st.session_state.authenticated:
        st.image("fondo.jpeg", use_container_width=True)

        if st.session_state.login_mode == "login":
            st.title("Inicio de sesión 🔐")
            username = st.text_input("Usuario", key="login_usuario")
            password = st.text_input("Contraseña", type="password", key="login_password")

            if st.button("Iniciar sesión"):
                if check_credentials(username, password):
                    st.session_state.authenticated = True
                    st.session_state.username = username
                    st.success("¡Inicio de sesión exitoso!")
                    st.rerun()
                else:
                    st.error("Usuario o contraseña incorrectos.")

            col1, col2 = st.columns(2)
            with col1:
                if st.button("¿Olvidaste tu contraseña?"):
                    st.session_state.login_mode = "recovery"
                    st.rerun()
            with col2:
                if st.button("Crear cuenta"):
                    st.session_state.login_mode = "registro"
                    st.rerun()


        elif st.session_state.login_mode == "recovery":
            st.title("🔐 Recuperación de contraseña")
            usuario_rec = st.text_input("Ingresa el usuario que deseas recuperar")

            if usuario_rec in st.session_state.users:
                pin_input = st.text_input("Ingresa el PIN de seguridad", type="password")

                if st.button("Verificar PIN"):
                    perfil = st.session_state.user_profiles.get(usuario_rec, {})
                    pin_guardado = perfil.get("pin")

                    if pin_input == pin_guardado:
                        nueva_contra = st.text_input("Nueva contraseña", type="password")
                        confirmar_contra = st.text_input("Confirmar nueva contraseña", type="password")
                        if st.button("Actualizar contraseña"):
                            if nueva_contra and nueva_contra == confirmar_contra:
                                st.session_state.users[usuario_rec] = nueva_contra
                                guardar_usuarios(st.session_state.users)
                                st.success(f"Contraseña para usuario `{usuario_rec}` actualizada correctamente.")
                            else:
                                st.error("Las contraseñas no coinciden o están vacías.")
                    else:
                        st.error("PIN incorrecto.")
            else:
                st.warning("Usuario no encontrado.")

            if st.button("Volver al inicio de sesión"):
                st.session_state.login_mode = "login"
                st.rerun()


        elif st.session_state.login_mode == "registro":
            st.title("🆕 Crear nueva cuenta")

            nombre = st.text_input("Nombre")
            apellido = st.text_input("Apellido")

            opciones_puesto = ["Gerente", "Supervisor", "Analista", "Asistente", "Otro (especifique)"]
            puesto = st.selectbox("Puesto", opciones_puesto)
            if puesto == "Otro (especifique)":
                puesto = st.text_input("Especifique su puesto")

            genero = st.selectbox("Género", ["Masculino", "Femenino", "No binario", "Prefiero no decirlo", "Otro (especifique)"])
            if genero == "Otro (especifique)":
                genero = st.text_input("Especifique su género")

            nuevo_usuario = st.text_input("Username")
            nueva_contra = st.text_input("Contraseña", type="password", key="reg_nueva_contra")
            confirmar = st.text_input("Confirmar contraseña", type="password", key="reg_confirmar_contra")
            pin = st.text_input("PIN de seguridad (6 dígitos)", type="password", key="reg_pin")
            confirmar_pin = st.text_input("Confirmar PIN", type="password", key="reg_confirmar_pin")

            if st.button("Crear cuenta"):
                if not (nombre and apellido and puesto and genero and nuevo_usuario and nueva_contra and confirmar and pin and confirmar_pin):
                    st.warning("Por favor completa todos los campos.")
                elif nuevo_usuario in st.session_state.users:
                    st.warning("Ese usuario ya existe.")
                elif nueva_contra != confirmar:
                    st.error("Las contraseñas no coinciden.")
                elif not pin.isdigit() or len(pin) != 6:
                    st.error("El PIN debe ser numérico y de 6 dígitos.")
                elif pin != confirmar_pin:
                    st.error("Los PINs no coinciden.")
                else:
                    st.session_state.users[nuevo_usuario] = nueva_contra
                    st.session_state.user_profiles[nuevo_usuario] = {
                        "nombre": nombre,
                        "apellido": apellido,
                        "puesto": puesto,
                        "genero": genero,
                        "pin": pin
                    }

                    guardar_usuarios(st.session_state.users)  
                    guardar_perfiles(st.session_state.user_profiles)  

                    st.success("✅ Cuenta creada con éxito. Ahora puedes iniciar sesión.")
                    st.session_state.login_mode = "login"
                    st.rerun()


            if st.button("Volver al inicio de sesión"):
                st.session_state.login_mode = "login"
                st.rerun()
    else:
        st.image("fondo.jpeg", use_container_width=True)

        perfil = st.session_state.user_profiles.get(st.session_state.username, {})
        genero = perfil.get("genero", "").lower()

        if "masculino" in genero:
            saludo = "Bienvenido"
        elif "femenino" in genero:
            saludo = "Bienvenida"
        elif "no binario" in genero or "prefiero" in genero or "otro" in genero:
            saludo = "¡Hola!"
        else:
            saludo = "Bienvenidx"

        st.title(f"{saludo}, {st.session_state.username} 👋")

        # Menu según usuario
        if st.session_state.username == "admin":
            opciones_menu = ["📊 Reportes", "⚙️ Configuración"]
        else:
            opciones_menu = ["🔮 Predicción", "🔍 Consulta", "⚙️ Configuración"]

        opcion = st.selectbox("Selecciona una opción:", opciones_menu)

        st.divider()

        if opcion == "🔮 Predicción":
            run_prediccion(modelo_rf)
        elif opcion == "🔍 Consulta":
            run_consulta()
        elif opcion == "📊 Reportes":
            run_reportes()
        elif opcion == "⚙️ Configuración":
            es_admin = (st.session_state.username == "admin")
            run_configuracion(es_admin)

        st.divider()
        if st.button("Cerrar sesión"):
            st.session_state.authenticated = False
            st.session_state.username = ""
            st.session_state.login_mode = "login"
            st.rerun()

if __name__ == "__main__":
    main()
