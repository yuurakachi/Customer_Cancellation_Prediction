import streamlit as st

def run_configuracion(es_admin):
    st.markdown("""
        <style>
        .main .block-container {
            padding-top: 2rem;
            padding-left: 3rem;
            padding-right: 3rem;
            max-width: 1200px;
        }
        body {
            background-color: #f9f9f9;
        }
        img {
            margin-top: -30px;
            margin-bottom: 20px;
        }
        </style>
    """, unsafe_allow_html=True)

    st.title("⚙️ Configuración")

    if es_admin:
        st.header("Parámetros del Modelo")
        umbral_alto = st.slider("Umbral para llamar inmediatamente", 0.7, 1.0, st.session_state.get("umbral_alto", 0.9), 0.01)
        umbral_medio = st.slider("Umbral para enviar correo", 0.5, umbral_alto, st.session_state.get("umbral_medio", 0.7), 0.01)
        umbral_bajo = st.slider("Umbral para monitorear", 0.0, umbral_medio, st.session_state.get("umbral_bajo", 0.5), 0.01)

        st.markdown(f"""
        **Umbrales actuales:**
        - 📞 Llamar inmediatamente: > {umbral_alto}  
        - 📧 Enviar correo: > {umbral_medio}  
        - 👁️‍🗨️ Monitorear: > {umbral_bajo}  
        - ✅ Sin acción: ≤ {umbral_bajo}  
        """)

        if st.button("Guardar configuración"):
            st.session_state.umbral_alto = umbral_alto
            st.session_state.umbral_medio = umbral_medio
            st.session_state.umbral_bajo = umbral_bajo

            st.success("✅ Configuración guardada")
            st.rerun()

        st.subheader("⚙️ Configuración de usuarios")

        if not st.session_state.user_profiles:
            st.info("No hay datos registrados todavía.")
            return

        for usuario, perfil in st.session_state.user_profiles.items():
            with st.expander(f"👤 {usuario}"):
                st.text_input("Nombre", value=perfil.get("nombre", ""), disabled=True)
                st.text_input("Apellido", value=perfil.get("apellido", ""), disabled=True) 
                st.text_input("Puesto", value=perfil.get("puesto", ""), disabled=True)
                st.text_input("Usuario", value=usuario, key=f"usuario_{usuario}", disabled=True)

    else:
        st.subheader("⚙️ Configuración de usuario")

        puestos = ["Gerente", "Analista", "Desarrollador", "Soporte", "Otro"]
        generos = ["Masculino", "Femenino", "No binario", "Prefiero no decir"]

        usuario = st.session_state.username
        perfil = st.session_state.user_profiles.get(usuario, {})

        if not perfil:
            st.warning("No hay datos registrados todavía.")
            return

        # Mostrar tabla de usuarios (solo para admin)
        if usuario == "admin":
            st.text_input("Nombre", value=perfil.get("nombre", ""), disabled=True)
            st.text_input("Apellido", value=perfil.get("apellido", ""), disabled=True)

            puesto_actual = perfil.get("puesto", puestos[0])
            genero_actual = perfil.get("genero", generos[0])

            st.selectbox("Puesto", options=puestos, index=puestos.index(puesto_actual) if puesto_actual in puestos else 0, disabled=True)
            st.selectbox("Género", options=generos, index=generos.index(genero_actual) if genero_actual in generos else 0, disabled=True)

            return 

        st.markdown("### 👤 Mi Perfil")

        # Usamos sesión para guardar estado de si está habilitada la edición
        if f"editar_habilitado_{usuario}" not in st.session_state:
            st.session_state[f"editar_habilitado_{usuario}"] = False

        if not st.session_state[f"editar_habilitado_{usuario}"]:
            # Pedir PIN para habilitar edición
            pin_input = st.text_input("Ingrese PIN de seguridad para habilitar edición", type="password", key=f"pin_input_{usuario}")
            if st.button("Habilitar edición"):
                if pin_input == perfil.get("pin"):
                    st.session_state[f"editar_habilitado_{usuario}"] = True
                    st.success("Edición habilitada")
                    st.rerun()
                else:
                    st.error("PIN incorrecto. No se puede habilitar la edición.")

            # Mostrar datos en modo solo lectura
            st.text_input("Nombre", value=perfil.get("nombre", ""), disabled=True)
            st.text_input("Apellido", value=perfil.get("apellido", ""), disabled=True)

            puesto_actual = perfil.get("puesto", puestos[0])
            genero_actual = perfil.get("genero", generos[0])

            st.selectbox("Puesto", options=puestos, index=puestos.index(puesto_actual) if puesto_actual in puestos else 0, disabled=True)
            st.selectbox("Género", options=generos, index=generos.index(genero_actual) if genero_actual in generos else 0, disabled=True)

        else:
            # Edición habilitada: campos editables
            nombre = st.text_input("Nombre", value=perfil.get("nombre", ""), key=f"nombre_{usuario}")
            apellido = st.text_input("Apellido", value=perfil.get("apellido", ""), key=f"apellido_{usuario}")

            puesto_actual = perfil.get("puesto", puestos[0])
            genero_actual = perfil.get("genero", generos[0])

            idx_puesto = puestos.index(puesto_actual) if puesto_actual in puestos else 0
            idx_genero = generos.index(genero_actual) if genero_actual in generos else 0

            puesto = st.selectbox("Puesto", options=puestos, index=idx_puesto, key=f"puesto_{usuario}")
            genero = st.selectbox("Género", options=generos, index=idx_genero, key=f"genero_{usuario}")

            if st.button("Guardar cambios"):
                st.session_state.user_profiles[usuario].update({
                    "nombre": nombre,
                    "apellido": apellido,
                    "puesto": puesto,
                    "genero": genero
                })
                st.success(f"Perfil actualizado para {usuario}.")
                st.session_state[f"editar_habilitado_{usuario}"] = False
                st.rerun()

        # Opciones de mostrar/cambiar contraseña igual que antes
        if st.checkbox("Mostrar contraseña", key=f"mostrar_contra_{usuario}"):
            pin_ingresado = st.text_input("PIN de seguridad", type="password", key=f"pin_ver_{usuario}")
            if st.button("Ver contraseña"):
                if pin_ingresado == perfil.get("pin"):
                    st.info(f"Contraseña actual: `{st.session_state.users.get(usuario, 'No disponible')}`")
                else:
                    st.error("PIN incorrecto. No se puede mostrar la contraseña.")

        if st.checkbox("Cambiar contraseña", key=f"cambiar_contra_{usuario}"):
            nueva_contra = st.text_input("Nueva contraseña", type="password", key=f"nueva_contra_{usuario}")
            pin_confirmar = st.text_input("PIN de seguridad", type="password", key=f"pin_conf_{usuario}")
            if st.button("Actualizar contraseña"):
                if pin_confirmar == perfil.get("pin"):
                    st.session_state.users[usuario] = nueva_contra
                    st.success("Contraseña actualizada correctamente.")
                else:
                    st.error("PIN incorrecto. No se puede cambiar la contraseña.")