import streamlit as st
import pandas as pd
import numpy as np
import os
import json
import requests
import plotly.express as px
from sklearn.metrics import roc_curve, auc
from backend import load_datasets, generate_visualization_data, prepare_data_for_models


# Cargar diccionarios  
with open(r"dictionaries\agency_dict.json", "r", encoding="utf-8") as f:
    agendy_dict = json.load(f)

with open(r"dictionaries\channel_dict.json", "r", encoding="utf-8") as f:
    channel_dict = json.load(f)

with open(r"dictionaries\states_dict.json", "r", encoding="utf-8") as f:
    states_dict = json.load(f)

def run_prediccion(modelo_rf):
    st.title("🔍 Predicción de Cancelaciones")

    # Usa los umbrales guardados o valores por defecto
    umbral_alto = st.session_state.get("umbral_alto", 0.7)
    umbral_medio = st.session_state.get("umbral_medio", 0.6)
    umbral_bajo = st.session_state.get("umbral_bajo", 0.5)

    def cargar_archivo(archivo):
        ext = os.path.splitext(archivo.name)[1].lower()
        if ext == ".parquet":
            return pd.read_parquet(archivo)
        elif ext == ".csv":
            return pd.read_csv(archivo)
        elif ext == ".xlsx":
            return pd.read_excel(archivo)
        return None

    # Inicializar en session_state si no existe
    if "archivo_cargado" not in st.session_state:
        st.session_state.archivo_cargado = None
    if "df" not in st.session_state:
        st.session_state.df = None
    if "fecha_inicio" not in st.session_state:
        st.session_state.fecha_inicio = None
    if "fecha_fin" not in st.session_state:
        st.session_state.fecha_fin = None
    if "columnas_visibles" not in st.session_state:
        st.session_state.columnas_visibles = ["ID_Reserva", "h_res_fec"]
    if "tabla_resultado" not in st.session_state:
        st.session_state.tabla_resultado = None

    # Sidebar para cargar archivo
    archivo_subido = st.sidebar.file_uploader("Carga un archivo (.parquet, .csv, .xlsx)", type=["parquet", "csv", "xlsx"])

    # Si suben archivo nuevo, procesar y guardar
    if archivo_subido is not None:
        if (st.session_state.archivo_cargado is None) or (archivo_subido.name != st.session_state.archivo_cargado.name):
            st.session_state.archivo_cargado = archivo_subido
            df = cargar_archivo(archivo_subido)
            df = load_datasets(df, pd.read_csv(r"Datasets/iar_Agencias.csv"))
            df["h_res_fec"] = pd.to_datetime(df["h_res_fec"].astype(str), format="%Y%m%d", errors="coerce")

            df["ID_Agencia"] = df["ID_Agencia"].astype(str).map(agendy_dict)
            df["ID_canal"] = df["ID_canal"].astype(str).map(channel_dict)
            df["Estado_cve_agencia"] = df["Estado_cve_agencia"].astype(str).map(states_dict)

            st.session_state.df = df

            # Reiniciar filtros cuando cambio archivo
            st.session_state.fecha_inicio = df["h_res_fec"].min()
            st.session_state.fecha_fin = df["h_res_fec"].max()
            st.session_state.columnas_visibles = ["ID_Reserva", "h_res_fec", "ID_Agencia", "h_can_res", "ID_Tipo_Habitacion"]
            st.session_state.tabla_resultado = None

    df = st.session_state.df

    if df is not None:
        # Fechas: mostrar sidebar date_input con valores guardados o default
        fecha_min = df["h_res_fec"].min()
        fecha_max = df["h_res_fec"].max()

        fecha_inicio_raw, fecha_fin_raw = st.sidebar.date_input(
            "Filtra por fechas",
            value=[st.session_state.fecha_inicio or fecha_min, st.session_state.fecha_fin or fecha_max],
            min_value=fecha_min,
            max_value=fecha_max,
        )

        # Guardar selección en session_state
        st.session_state.fecha_inicio = pd.to_datetime(fecha_inicio_raw)
        st.session_state.fecha_fin = pd.to_datetime(fecha_fin_raw)

        # Multiselect variables a mostrar con persistencia
        columnas_visibles = st.sidebar.multiselect(
            "Elige variables a mostrar",
            options=list(df.columns),
            default=st.session_state.columnas_visibles
        )
        st.session_state.columnas_visibles = columnas_visibles

        # Filtrar df por fechas
        df_filtrado = df[(df["h_res_fec"] >= st.session_state.fecha_inicio) & (df["h_res_fec"] <= st.session_state.fecha_fin)]

        # Preparar datos para modelo
        X_model = prepare_data_for_models(df)
        X_filtrado = X_model.loc[df_filtrado.index]

        def recomendar(prob):
            if prob > umbral_alto:
                return "Llamar inmediatamente y ofrecer incentivo"
            elif prob > umbral_medio:
                return "Enviar correo de reconfirmación"
            elif prob > umbral_bajo:
                return "Monitorear, posible riesgo"
            else:
                return "Sin acción necesaria"

        X_modelo = X_filtrado.drop(columns=["ID_Reserva"], errors="ignore")
        X_modelo = X_modelo[sorted(X_modelo.columns)]
        if modelo_rf is not None:
            y_pred_prob = modelo_rf.predict_proba(X_modelo)[:, 1]
            print(repr(y_pred_prob))
            y_pred = modelo_rf.predict(X_modelo)
            print(repr(y_pred))
        else:
            endpoint_uri = "http://bb01f333-c18e-4d7b-8146-5b8ec0d6fc22.centralindia.azurecontainer.io/score"
            X = X_modelo
            X_0 = X.to_dict(orient="records")

            headers = {
                "Content-Type": "application/json"
            }

            payload = json.dumps({ "data": X_0 })
            response = requests.post(endpoint_uri, headers=headers, data=payload)
            response_json = response.json()
            dictionary_data = json.loads(response_json)
            y_pred_prob = dictionary_data["probabilidades"]
            y_pred = dictionary_data["predicciones"]
            y_pred_prob = np.array(y_pred_prob)
            y_pred = np.array(y_pred)
            print(repr(y_pred_prob))
            print(repr(y_pred))


        tabla_resultado = df_filtrado[st.session_state.columnas_visibles].copy()
        tabla_resultado["h_res_fec"] = tabla_resultado["h_res_fec"].dt.strftime("%d/%m/%Y")
        tabla_resultado["Probabilidad de cancelación"] = y_pred_prob.round(3)
        tabla_resultado["Cancelación prevista"] = np.where(y_pred == 1, "Sí", "No")
        tabla_resultado["Recomendador de acción comercial"] = tabla_resultado["Probabilidad de cancelación"].apply(recomendar)

        st.session_state["tabla_resultado"] = tabla_resultado  # Guardar tabla para otras páginas 

        if "user_data_records" not in st.session_state:
            st.session_state.user_data_records = {}

        st.session_state.user_data_records[st.session_state["username"]] = tabla_resultado.to_dict()
        
        st.subheader("📋 Resultados de Predicción")
        st.dataframe(tabla_resultado, use_container_width=True)
        st.download_button("📥 Descargar resultados", tabla_resultado.to_csv(index=False).encode("utf-8"), file_name="predicciones.csv")

        st.subheader("📊 Visualizaciones")

        # ----------- Primera fila: Agencias + Canales -----------
        col1, col2 = st.columns(2)

        with col1:
            st.markdown("#### Top 10 Agencias con más Cancelaciones")
            if "ID_Agencia" in tabla_resultado.columns and "Cancelación prevista" in tabla_resultado.columns:
                agencias_cancelaciones = tabla_resultado[tabla_resultado["Cancelación prevista"] == "Sí"]
                top_agencias = agencias_cancelaciones["ID_Agencia"].value_counts().head(10)
                fig1 = px.pie(
                    values=top_agencias.values,
                    names=top_agencias.index,
                    hole=0.4,
                )
                fig1.update_traces(textinfo='percent+label')
                fig1.update_layout(height=400, showlegend=False) 
                st.plotly_chart(fig1, use_container_width=True)
            else:
                st.warning("No se encontró la columna 'ID_Agencia' o 'Cancelación prevista' en los datos.")

        with col2:
            st.markdown("#### Top 10 Canales con más Cancelaciones")
            if "h_can_res" in tabla_resultado.columns:
                try:

                    # Convertir la columna a string y mapear los nombres
                    tabla_resultado["Canal_Nombre"] = tabla_resultado["h_can_res"].astype(str).map(channel_dict)

                    # Filtrar filas con canal definido
                    canales_cancelaciones = tabla_resultado[tabla_resultado["Canal_Nombre"].notna()]

                    # Contar top 10 canales por nombre
                    top_canales = canales_cancelaciones["Canal_Nombre"].value_counts().head(10).reset_index()
                    top_canales.columns = ["Canal", "Cantidad"]

                    # Ordenar por cantidad descendente
                    top_canales = top_canales.sort_values(by="Cantidad", ascending=False)

                    # Categorías ordenadas para el eje Y
                    top_canales["Canal"] = pd.Categorical(
                        top_canales["Canal"],
                        categories=top_canales["Canal"],
                        ordered=True
                    )

                    fig2 = px.bar(
                        top_canales,
                        x="Cantidad",
                        y="Canal",
                        orientation='h',
                        color="Canal",
                        color_discrete_sequence=px.colors.qualitative.Set3
                    )
                    fig2.update_layout(height=400, showlegend=False) 
                    st.plotly_chart(fig2, use_container_width=True)
                except Exception as e:
                    st.error(f"Error al cargar o procesar canales: {e}")
            else:
                st.warning("No se encontraron datos de canales de reserva.")


        # ----------- Segunda fila: Recomendaciones + Reservas por mes -----------
        col3, col4 = st.columns(2)

        with col3:
            st.markdown("#### Recomendaciones Comerciales")
            if "Recomendador de acción comercial" in tabla_resultado.columns:
                fig3 = px.bar(
                    tabla_resultado.groupby("Recomendador de acción comercial").size().reset_index(name="Cantidad"),
                    x="Recomendador de acción comercial",
                    y="Cantidad",
                    color="Recomendador de acción comercial"
                )
                fig3.update_layout(height=400, showlegend=False)
                st.plotly_chart(fig3, use_container_width=True)
            else:
                st.warning("No se encontró la columna 'Recomendador de acción comercial'.")

        with col4:
            st.markdown("#### Reservas por Mes (Apiladas por Cancelación)")
            if "h_res_fec" in tabla_resultado.columns and "Cancelación prevista" in tabla_resultado.columns:
                tabla_resultado["h_res_fec"] = pd.to_datetime(tabla_resultado["h_res_fec"], errors="coerce")
                # tabla_resultado = tabla_resultado[tabla_resultado["h_res_fec"] >= "2022-01-01"]  
                tabla_resultado["Mes"] = tabla_resultado["h_res_fec"].dt.month
                tabla_resultado["Año"] = tabla_resultado["h_res_fec"].dt.year

                reservas_por_mes = tabla_resultado.groupby(["Año", "Mes", "Cancelación prevista"]).size().reset_index(name="Cantidad")
                reservas_por_mes["MesNombre"] = reservas_por_mes["Mes"].apply(
                    lambda x: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"][x - 1]
                )
                reservas_por_mes["Periodo"] = reservas_por_mes["MesNombre"] + " " + reservas_por_mes["Año"].astype(str)
                reservas_por_mes = reservas_por_mes.sort_values(["Año", "Mes"])

                fig4 = px.bar(
                    reservas_por_mes,
                    x="Periodo",
                    y="Cantidad",
                    color="Cancelación prevista",
                    labels={"Cantidad": "Número de Reservas", "Periodo": "Mes"},
                    color_discrete_map={"Sí": "crimson", "No": "skyblue"},
                )
                fig4.update_layout(barmode="relative", xaxis_tickangle=-45, height=400)
                st.plotly_chart(fig4, use_container_width=True)
            else:
                st.warning("No se encontró la columna 'h_res_fec' o 'Cancelación prevista' en los datos.")

        # ----------- Tercera fila: Pie total de cancelaciones -----------
        col5, col6 = st.columns(2)

        with col5:
            st.markdown("### Tarifa Estimada por Mes (Sólo Cancelaciones)")

            if (
                "h_res_fec" in tabla_resultado.columns and
                "Cancelación prevista" in tabla_resultado.columns and
                "ID_Tipo_Habitacion" in tabla_resultado.columns
            ):
                try:
                    with open(r"transformations\avg_noc_dict_interpretable.json", "r") as f:
                        avg_tarifa_dict = json.load(f)

                    cancelaciones = tabla_resultado[tabla_resultado["Cancelación prevista"] == "Sí"].copy()
                    cancelaciones["h_res_fec"] = pd.to_datetime(cancelaciones["h_res_fec"], errors="coerce")
                    cancelaciones = cancelaciones[cancelaciones["h_res_fec"].notna()]

                    cancelaciones["Mes"] = cancelaciones["h_res_fec"].dt.month
                    cancelaciones["Año"] = cancelaciones["h_res_fec"].dt.year

                    # Aseguramos que los IDs de tipo de habitación estén limpios
                    cancelaciones["ID_Tipo_Habitacion"] = cancelaciones["ID_Tipo_Habitacion"].astype(str).str.strip()
                    avg_tarifa_dict = {str(k).strip(): v for k, v in avg_tarifa_dict.items()}

                    # Mapear tarifa estimada según el tipo de habitación
                    cancelaciones["tarifa_estimada"] = cancelaciones["ID_Tipo_Habitacion"].map(avg_tarifa_dict)
                    cancelaciones = cancelaciones[cancelaciones["tarifa_estimada"].notna()]

                    if not cancelaciones.empty:
                        resumen_tarifas = cancelaciones.groupby(["Año", "Mes"])["tarifa_estimada"].sum().reset_index()
                        resumen_tarifas["MesNombre"] = resumen_tarifas["Mes"].apply(
                            lambda x: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"][x - 1]
                        )
                        resumen_tarifas["Periodo"] = resumen_tarifas["MesNombre"] + " " + resumen_tarifas["Año"].astype(str)
                        resumen_tarifas = resumen_tarifas.sort_values(["Año", "Mes"])

                        fig6 = px.line(
                            resumen_tarifas,
                            x="Periodo",
                            y="tarifa_estimada",
                            labels={"tarifa_estimada": "Tarifa Estimada Total", "Periodo": "Mes"},
                            markers=True
                        )
                        fig6.update_traces(line=dict(color='red'))
                        fig6.update_layout(height=400, xaxis_tickangle=-45)
                        st.plotly_chart(fig6, use_container_width=True)
                    else:
                        st.warning("No hay datos válidos de tarifa estimada para cancelar.")
                except Exception as e:
                    st.error(f"Error al cargar o procesar tarifas: {e}")
            else:
                st.warning("No se encontró la columna 'h_res_fec', 'Cancelación prevista' o 'ID_Tipo_Habitacion'.")

        with col6:
            st.markdown("### Proporción Total de Cancelaciones")

            if "Cancelación prevista" in tabla_resultado.columns:
                total_cancelaciones = tabla_resultado["Cancelación prevista"].value_counts().reset_index()
                total_cancelaciones.columns = ["Cancelación", "Cantidad"]

                fig5 = px.pie(
                    total_cancelaciones,
                    names="Cancelación",
                    values="Cantidad",
                    title="Distribución Global de Cancelaciones",
                    hole=0.4
                )
                fig5.update_traces(textinfo='percent+label')
                fig5.update_layout(height=400)

                st.plotly_chart(fig5, use_container_width=True)
            else:
                st.warning("No se encontró la columna 'Cancelación prevista' en los datos.")
    else:
        st.info("Por favor, carga un archivo para habilitar filtros y predicciones.")
