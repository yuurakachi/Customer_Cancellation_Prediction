import streamlit as st
import pandas as pd

from utils import guardar_acciones, cargar_acciones

def run_consulta():
    st.title("🔎 Consulta por ID_Reserva")

    if "acciones_guardadas" not in st.session_state:
        st.session_state["acciones_guardadas"] = cargar_acciones()

    if "tabla_resultado" not in st.session_state or not isinstance(st.session_state["tabla_resultado"], pd.DataFrame) or st.session_state["tabla_resultado"].empty:
        st.info("🔁 Primero realiza una predicción en la sección anterior.")
        st.stop()

    tabla_resultado = st.session_state["tabla_resultado"]

    # IDs con probabilidad > 0.7
    ids_en_riesgo = tabla_resultado[tabla_resultado["Probabilidad de cancelación"] > 0.7]["ID_Reserva"].unique().tolist()

    # IDs que ya tienen acciones guardadas
    ids_accionados = []
    if "acciones_guardadas" in st.session_state and not st.session_state["acciones_guardadas"].empty:
        ids_accionados = st.session_state["acciones_guardadas"]["ID_Reserva"].unique().tolist()

    # Filtrar para mostrar solo IDs en riesgo que no hayan sido accionados
    opciones_id = [id_ for id_ in ids_en_riesgo if id_ not in ids_accionados]

    if not opciones_id:
        st.info("No hay reservaciones en riesgo pendientes por accionar.")
        st.stop()

    id_seleccionado = st.selectbox("Selecciona ID de Reserva", opciones_id)

    reserva = tabla_resultado[tabla_resultado["ID_Reserva"] == id_seleccionado]
    st.dataframe(reserva)

    st.markdown("### 🛠 Acciones tomadas")
    promo = st.selectbox("¿Se ofreció una promoción?", ["Sí", "No"])
    contacto = st.selectbox("¿Hubo contacto?", ["Llamada", "Correo", "SMS", "No se contactó"])
    resultado = st.text_area("Resultado o comentario adicional")

    usuario = st.session_state.get("username", "Desconocido")

    # Inicializar DataFrame con columnas correctas para evitar KeyError
    if "acciones_guardadas" not in st.session_state:
        st.session_state["acciones_guardadas"] = pd.DataFrame(columns=[
            *tabla_resultado.columns, "Promoción Ofrecida", "Contacto", "Comentario", "Usuario"
        ])

    if st.button("Agregar acción a la lista"):
        datos_guardar = reserva.copy()
        datos_guardar["Promoción Ofrecida"] = promo
        datos_guardar["Contacto"] = contacto
        datos_guardar["Comentario"] = resultado
        datos_guardar["Usuario"] = usuario

        # Llamada correcta a guardar_acciones
        id_reserva = datos_guardar["ID_Reserva"].values[0]
        accion = f"Promoción: {promo}, Contacto: {contacto}, Comentario: {resultado}"
        fila_a_guardar = datos_guardar.iloc[0]

        if "Probabilidad de cancelación" not in fila_a_guardar:
            prob = tabla_resultado.loc[tabla_resultado["ID_Reserva"] == id_seleccionado, "Probabilidad de cancelación"].values[0]
            fila_a_guardar["Probabilidad de cancelación"] = prob

        guardar_acciones(fila_a_guardar)

        df_acciones = st.session_state["acciones_guardadas"]

        # Evitar duplicados por ID_Reserva (opcional)
        if not df_acciones.empty and "ID_Reserva" in df_acciones.columns:
            df_acciones = df_acciones[df_acciones["ID_Reserva"] != id_seleccionado]

        df_acciones = pd.concat([df_acciones, datos_guardar], ignore_index=True)
        st.session_state["acciones_guardadas"] = df_acciones
        guardar_acciones(df_acciones)
        st.success(f"✅ Acción para ID_Reserva {id_seleccionado} agregada a la lista.")


    st.markdown("### 📋 Acciones agregadas hasta ahora")
    if not st.session_state["acciones_guardadas"].empty:
        st.dataframe(st.session_state["acciones_guardadas"])

        if st.button("Exportar todo a CSV"):
            csv = st.session_state["acciones_guardadas"].to_csv(index=False).encode('utf-8')
            st.download_button(
                label="Descargar archivo CSV",
                data=csv,
                file_name="acciones_guardadas.csv",
                mime="text/csv"
            )
    else:
        st.info("No hay acciones agregadas aún.")
