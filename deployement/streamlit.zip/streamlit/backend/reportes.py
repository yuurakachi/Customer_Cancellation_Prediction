import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

def run_reportes():
    st.title("📊 Reportes y seguimiento")

    if "tabla_resultado" not in st.session_state or st.session_state["tabla_resultado"].empty:
        # Intentar cargarlo desde acciones_guardadas si no está en memoria
        df_acc = st.session_state["acciones_guardadas"]
        if "ID_Reserva" in df_acc.columns and "Probabilidad de cancelación" in df_acc.columns:
            st.session_state["tabla_resultado"] = df_acc[["ID_Reserva", "Probabilidad de cancelación"]].drop_duplicates()
        else:
            st.warning("No hay resultados de predicción para mostrar KPIs.")
            return

    if "acciones_guardadas" not in st.session_state or st.session_state["acciones_guardadas"].empty:
        st.warning("No hay acciones registradas para mostrar métricas.")
        return

    df = st.session_state["acciones_guardadas"]

    # --- FILTROS ---
    st.sidebar.header("Filtros")

    # Filtro por usuario
    usuarios = df["Usuario"].unique().tolist()
    usuario_seleccionado = st.sidebar.multiselect("Selecciona usuario(s)", usuarios, default=usuarios)

    # Filtro por rango de fechas 
    if "Fecha" in df.columns:
        fecha_min = df["Fecha"].min()
        fecha_max = df["Fecha"].max()
        fecha_inicio, fecha_fin = st.sidebar.date_input("Rango de fechas", [fecha_min, fecha_max])
        df = df[(df["Fecha"] >= pd.to_datetime(fecha_inicio)) & (df["Fecha"] <= pd.to_datetime(fecha_fin))]

    # Aplicar filtro por usuario
    df = df[df["Usuario"].isin(usuario_seleccionado)]

    # --- KPIs GENERALES ---
    st.subheader("KPIs generales")

    tabla_resultado = st.session_state.get("tabla_resultado")
    if tabla_resultado is None or tabla_resultado.empty:
        st.warning("No hay resultados de predicción para mostrar KPIs.")
        return
    
    if "Probabilidad de cancelación" not in df.columns:
        st.warning("No hay información de predicción (Probabilidad de cancelación) en las acciones registradas.")
        return

    umbral_alto = st.session_state.get("umbral_alto", 0.7)

    # Filtrar por riesgo alto
    df_riesgo_alto = df[df["Probabilidad de cancelación"] > umbral_alto]

    total_reservas_riesgo = tabla_resultado[tabla_resultado["Probabilidad de cancelación"] > umbral_alto]["ID_Reserva"].nunique()
    total_acciones = df_riesgo_alto["ID_Reserva"].nunique()
    promo_ofrecidas = df_riesgo_alto[df_riesgo_alto["Promoción Ofrecida"] == "Sí"].shape[0]

    porcentaje_acciones = (total_acciones / total_reservas_riesgo * 100) if total_reservas_riesgo > 0 else 0

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total reservas en riesgo", total_reservas_riesgo)
    col2.metric("Acciones registradas", total_acciones)
    col3.metric("Promociones ofrecidas", promo_ofrecidas)
    col4.metric("Acciones / Reserva (%)", f"{porcentaje_acciones:.2f}%")

    # --- MÉTRICAS POR USUARIO ---
    st.subheader("Métricas por usuario")
    promociones_por_usuario = df[df["Promoción Ofrecida"] == "Sí"].groupby("Usuario").size()
    contacto_por_usuario = df.groupby(["Usuario", "Contacto"]).size().unstack(fill_value=0)

    st.bar_chart(promociones_por_usuario.rename("Promociones por usuario"))

    st.markdown("**Contacto por usuario:**")
    st.dataframe(contacto_por_usuario)

    # --- VISUALIZACIONES INTERACTIVAS ---
    st.subheader("Visualizaciones de contacto")

    contacto_counts = df["Contacto"].value_counts()
    st.bar_chart(contacto_counts)

    # Opcional: gráfico de pastel para contacto
    st.markdown("**Distribución de tipo de contacto:**")

    fig, ax = plt.subplots()
    ax.pie(contacto_counts, labels=contacto_counts.index, autopct="%1.1f%%", startangle=90)
    ax.axis("equal")
    st.pyplot(fig)

    # --- TABLA DETALLADA CON FILTROS ---
    st.subheader("Detalle de acciones registradas")
    st.dataframe(df)

    # --- EXPORTACIÓN ---
    csv = df.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="Exportar reporte a CSV",
        data=csv,
        file_name="reporte_acciones.csv",
        mime="text/csv"
    )